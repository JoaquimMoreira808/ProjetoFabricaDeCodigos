from flask import Flask, request, render_template
from groq import Groq

app = Flask(__name__)

api_key = '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'
cliente = Groq(api_key=api_key)

@app.route('/', methods=['GET', 'POST'])
def index():
    resposta = ""
    if request.method == 'POST':
        user_input = request.form['user_input']
        chat_completion = cliente.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": """ Você serve para dar informações sobre esse produto. Priorize respostas curtas e objetivas. Não forneça nada além dessas informações. Em caso de aparente burrice ou assunto que não seja referente ao produto retorne apenas: Não entendi, tente alguma das perguntas acima.
    "produtos": [
      {
        "id": 101,
        "nome": "Para-choque Dianteiro Esportivo",
        "compatibilidade": [
          {
            "marca": "Honda",
            "modelos": ["Civic", "Civic Si"],
            "anos": [2016, 2017, 2018, 2019, 2020]
          },
          {
            "marca": "Toyota",
            "modelos": ["Corolla"],
            "anos": [2017, 2018, 2019, 2020]
          }
        ],
        "descricao": "Para-choque dianteiro esportivo fabricado em ABS de alta resistência, com design aerodinâmico e acabamento fosco, proporciona estilo e proteção superior ao veículo. Possui encaixe perfeito, seguindo as especificações originais de fábrica, garantindo fácil instalação. Inclui entradas de ar para melhorar a refrigeração do motor.",
        "material": "ABS de alta resistência",
        "cor": "Preto fosco",
        "preco": 1200.00,
        "disponibilidade": true,
        "peso": "5kg",
        "dimensoes": {
          "comprimento": "180 cm",
          "largura": "50 cm",
          "altura": "40 cm"
        }
        }
    ]
"""
                },
                {
                    "role": "user",
                    "content": user_input,
                }
            ],
            model="llama3-8b-8192",
        )
        resposta = chat_completion.choices[0].message.content
    return render_template('index.html', resposta=resposta)

if __name__ == '__main__':
    app.run(debug=True)