from flask import Flask, request, render_template
from groq import Groq
import json

app = Flask(__name__)

with open('produtos.json', 'r', encoding='utf-8') as f:
    produtos = json.load(f)

api_key = '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'
cliente = Groq(api_key=api_key)

@app.route('/', methods=['GET', 'POST'])
def index():
    resposta = ""
    if request.method == 'POST':
        user_input = request.form['user_input']
        chat_completion = cliente.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": "Você serve para tirar dúvidas sobre os produtos estabelecidos na varíavel 'produtos'. Não dê nenhuma informação que não conste neste arquivo."
                },
                {
                    "role": "user",
                    "content": user_input,
                }
            ],
            model="llama3-8b-8192"
        )
        resposta = chat_completion.choices[0].message.content
    return render_template('index.html', resposta=resposta)

if __name__ == '__main__':
    app.run(debug=True)