from flask import Flask, request, render_template
from groq import Groq

app = Flask(__name__)

api_key = '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'
cliente = Groq(api_key=api_key)

@app.route('/', methods=['GET', 'POST'])
def index():
    resposta = ""
    if request.method == 'POST':
        user_input = request.form['user_input']
        chat_completion = cliente.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": """ Você serve para dar informações sobre esses produtos. Não forneça nada além dessas informações. Em caso de aparente burrice retorne: Não entendi, tente alguma das perguntas acima.
    "produtos": [
      {
        "id": 1,
        "nome": "Pneu All-Season",
        "preco": 350.00,
        "descricao": "Pneu resistente para todas as estações, oferece boa tração em diferentes condições climáticas."
      },
      {
        "id": 2,
        "nome": "Bateria 60Ah",
        "preco": 450.00,
        "descricao": "Bateria automotiva de 60Ah com alta durabilidade e confiabilidade para carros de passeio."
      },
      {
        "id": 3,
        "nome": "Filtro de Óleo",
        "preco": 30.00,
        "descricao": "Filtro de óleo de alta eficiência, prolonga a vida útil do motor ao reter impurezas."
      },
      {
        "id": 4,
        "nome": "Câmera de Ré",
        "preco": 200.00,
        "descricao": "Câmera de ré compacta com visão noturna para facilitar manobras e garantir segurança."
      },
      {
        "id": 5,
        "nome": "Alto-Falante Automotivo",
        "preco": 180.00,
        "descricao": "Alto-falante de 6 polegadas com som de alta qualidade para sistemas de som automotivo."
      },
      {
        "id": 6,
        "nome": "Palheta Limpador de Para-brisa",
        "preco": 40.00,
        "descricao": "Palheta de alta durabilidade, ideal para garantir uma visibilidade clara em dias chuvosos."
      },
      {
        "id": 7,
        "nome": "Kit Xenon 6000K",
        "preco": 250.00,
        "descricao": "Farol xenon com luz branca intensa, melhora a visibilidade e estilo do veículo."
      },
      {
        "id": 8,
        "nome": "Capa de Banco em Couro",
        "preco": 400.00,
        "descricao": "Capa de banco em couro sintético, protege os assentos e adiciona elegância ao interior do carro."
      },
      {
        "id": 9,
        "nome": "Suporte para Celular",
        "preco": 50.00,
        "descricao": "Suporte ajustável para celular, ideal para navegação GPS e chamadas em viva-voz."
      },
      {
        "id": 10,
        "nome": "Calha de Chuva",
        "preco": 120.00,
        "descricao": "Calhas de chuva para as janelas, permitem abrir um pouco as janelas mesmo em dias chuvosos."
      }
    ]
"""
                },
                {
                    "role": "user",
                    "content": user_input,
                }
            ],
            model="llama3-8b-8192",
            temperature= 0
        )
        resposta = chat_completion.choices[0].message.content
    return render_template('index.html', resposta=resposta)

if __name__ == '__main__':
    app.run(debug=True)